/* -*- Mode: C; tab-width: 4 -*-
 *
 * Copyright (c) 2003-2004 Apple Computer, Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



#ifdef _MERGE_PROXYSTUB // merge proxy stub DLL



#define REGISTER_PROXY_DLL //DllRegisterServer, etc.



#define _WIN32_WINNT 0x0500	//for WinNT 4.0 or Win95 with DCOM

#define USE_STUBLESS_PROXY	//defined only with MIDL switch /Oicf



#pragma comment(lib, "rpcns4.lib")

#pragma comment(lib, "rpcrt4.lib")



#define ENTRY_PREFIX	Prx



#include "dlldata.c"

#include "DLLX_p.c"



#endif //_MERGE_PROXYSTUB

