//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by Application.rc
//
#define IDD_APPLICATION_DIALOG          102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_BROWSER_LIST_COLUMN_NAME    104
#define IDR_MAINFRAME                   128
#define IDC_BROWSE_LIST                 1000
#define IDC_IP_TEXT                     1003
#define IDC_TXT_TEXT                    1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
