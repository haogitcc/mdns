#ifndef DNSMessageTest_h
#define DNSMessageTest_h

#include "unittest.h"

int DNSMessageTest(void);

#endif /* DNSMessageTest_h */