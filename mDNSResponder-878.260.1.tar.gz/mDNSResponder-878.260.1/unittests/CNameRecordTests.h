
#ifndef ReconfirmRecordTests_h
#define ReconfirmRecordTests_h

#include "unittest.h"

int  CNameRecordTests(void);

#endif /* ReconfirmRecordTests_h */
